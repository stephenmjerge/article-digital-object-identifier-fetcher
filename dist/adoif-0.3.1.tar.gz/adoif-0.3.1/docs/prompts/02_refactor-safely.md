Extract shared utilities (logging/config/paths) without breaking the public CLI.
Propose a PR plan touching ≤5 files and a stepwise diff outline.
