Review this repo: list CLI commands, missing tests, and top 3 technical risks.
Output a 7-day plan with bite-size issues.
