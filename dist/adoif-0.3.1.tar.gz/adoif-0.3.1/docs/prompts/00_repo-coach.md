You are my repo coach. Goal: add <feature>.
1) Write a minimal acceptance test.
2) Propose the smallest function signatures.
3) Implement only what the test needs.
4) Add docstring + README snippet.
5) Propose one atomic commit message.
